// setting up the variables
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const db = require("./PP_Portal/Assets/hand-made/JS/db_insert");

const app = express();

// setting up session
app.use(
  session({
    secret: 'bh348h280h14bn',
    resave: false,
    saveUninitialized: true,
  })
);

app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'PP_Portal', 'views'));

// body parser acting as middleware for form handling. 
app.use(bodyParser.urlencoded({ extended: true }));

// creating the account login
app.post('/submit', (req, res) => {
   const email = req.body.Email;
   const password = req.body.Password;

   if (!email || !password) {
    res.status(400).send('Email and Password required');
    return;
   }

   const sql = 'INSERT INTO Account (Email, Password) VALUES (?, ?)';
   db.query(sql, [email, password], (err, result) => {
    if(err) {
      console.error('Error Adding account information: ' + err.stack);
      res.status(500).send('Internal Server Error');
    } else {
      console.log('Account created with ID ' + result.insertId);
      
      res.redirect('Patient-Profile.html');
    }
   });
});

// creating Profile
app.post('/create', (req, res) => {
  const f_name = req.body.fname;
  const l_name = req.body.lname;
  const phone = req.body.phone;
  const mrn = req.body.mrn;
  const insurance = req.body.insurance;
  const visit = req.body.visit;

  if (!f_name || !l_name || !phone || !mrn || !insurance || !visit){
    res.status(400).send('Please fill out the form');
    return;
  }

  const sql = 'INSERT INTO Profile (First_name, Last_name, Phone, MRN, Insurance, Reason) VALUES (?, ?, ?, ?, ?, ?)';
  db.query(sql, [f_name, l_name, phone, mrn, insurance, visit], (err, result) =>{
    if (err) {
      console.error('Error inserting into database: ' + err.stack);
      res.status(500).send('Internal Server Error');
    } else {
      console.log('Data inserted into database with ID ' + result.insertId);
      
      res.redirect('Profile.html');
    }
  });
});

// Logging into account
app.post('/login', (req, res) => {
  const { Email, password } = req.body;

  // Log incoming data for debugging
  console.log('Received login request. Email:', Email, 'Password:', password);


  // Check login information against the Account table
  const accountQuery = 'SELECT * FROM Account WHERE email = ? AND password = ?';
  db.query(accountQuery, [Email, password], (accountErr, accountResults) => {
    if (accountErr) {
      console.error('Error executing account query: ', accountErr);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    // Log the results of the account query
    console.log('Account Query Results:', accountResults);

    if (accountResults.length > 0) {
      const userId = accountResults[0].ID;

      // checking ID
      console.log('User ID:', userId);

      // Fetch user profile information from the Profile table based on the user ID
      const profileQuery = 'SELECT * FROM Profile WHERE id = ?';
      db.query(profileQuery, [userId], (profileErr, profileResults) => {
        if (profileErr) {
          console.error('Error executing profile query: ', profileErr);
          res.status(500).json({ error: 'Internal Server Error' });
          return;
        }

        // Log the results of the profile query
        console.log('Profile Query Results:', profileResults);

        if (profileResults.length > 0) {
          const userData = profileResults[0];
          req.session.user = { userId, ...userData }; // Store user data in the session
          res.redirect('/profile');
        } else {
          // User profile not found
          res.status(404).json({ error: 'User profile not found' });
        }
      });
    } else {
      // Login failed
      res.status(401).json({ error: 'Invalid email or password' });
    }
  });
});

// Inserting the data onto the SQL table
app.post('/submit', (req, res) => {
    const firstName = req.body.firstName;
    const lastName = req.body.lastName;
  
    // Basic validation to check if values are not empty
    if (!firstName || !lastName) {
      res.status(400).send('First Name and Last Name are required');
      return;
    }
  
    // Insert data into the database
    const sql = 'INSERT INTO name (First_name, Last_name) VALUES (?, ?)';
    db.query(sql, [firstName, lastName], (err, result) => {
      if (err) {
        console.error('Error inserting into database: ' + err.stack);
        res.status(500).send('Internal Server Error');
      } else {
        console.log('Data inserted into database with ID ' + result.insertId);
        
        res.redirect('/display-data');
      }
    });
});

// updating the data
app.post('/update-entry', (req, res) => {
  console.log('Form data recieved');
  const { editedID, editedFirstName, editedLastName } = req.body;

  const sql = 'UPDATE name SET First_name=?, Last_name=? WHERE id=?';
  const values = [editedFirstName, editedLastName, editedID];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error updating entry: ' + err.message);
      res.status(500).send('Error updating entry');
      return;
    }

    console.log('Entry updated:', result.affectedRows, 'rows affected');

    // Redirect back to the display-data page with the updated data
    res.redirect('/display-data');
  });
});

// Handle requests to the display-data page
app.get('/display-data', (req, res) => {
    // Retrieve data from the database
    const sql = 'SELECT * FROM name';
    db.query(sql, (err, result) => {
      if (err) {
        console.error('Error fetching data from database: ' + err.stack);
        res.status(500).send('Internal Server Error');
      } else {
        // Render the display-data.ejs page and pass the data
        res.render('display-data', { data: result });
      }
    });
});

// Route to display the profile
app.get('/profile', (req, res) => {
  // Check if the user is authenticated (logged in)
  if (req.session.user) {
    // Render the profile page with user data
    res.render('profile', { user: req.session.user });
  } else {
    // User is not authenticated, redirect to the login page
    res.redirect('/login.html');
  }
});

// launches from the directory
app.use(express.static(path.join(__dirname, 'PP_Portal')));

// if the page doesn't exist
app.use((req, res) => {
    res.status(404);
    res.send(`<h1>Error 404: Resource Not found</h1>`);
});

// notifcation that app has launched
app.listen(8080, () => {
    console.log(`App deployed at Port 8080`);
});