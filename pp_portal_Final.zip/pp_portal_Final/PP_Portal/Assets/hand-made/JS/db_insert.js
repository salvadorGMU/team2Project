// connecting to SQL database
const mysql = require('mysql');

const db = mysql.createConnection({
    host:'34.139.144.172',
    user: 'root',
    password: 'GMU2023',
    database: 'Test_EB'
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + db.threadId);
});

module.exports = db;