function goHome() {
    window.location.href = "index.html"
}


document.addEventListener('DOMContentLoaded', function() {
    function login() {
      console.log('login function called');
      window.location.href = "Login.html"
    }
    document.getElementById('LogBtn').addEventListener('click', login);
  });

document.getElementById('homebutton').addEventListener('click', goHome);