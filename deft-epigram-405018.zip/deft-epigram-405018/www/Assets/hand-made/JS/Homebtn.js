function goHome() {
    window.location.href = "index.html"
}

document.getElementById('homebutton').addEventListener('click', goHome);

function login() {
    window.location.href = "Login.html"
}

document.getElementById('LogBtn').addEventListener('click', login);