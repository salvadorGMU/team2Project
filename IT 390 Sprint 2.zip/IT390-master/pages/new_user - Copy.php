<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Probably the most complete UI kit out there. Multiple functionalities and controls added,  extended color palette and beautiful typography, designed as its own extended version of Bootstrap at  the highest level of quality.                             ">
    <meta name="author" content="Webpixels">
    <title>Patient Pathway Portal - IT 390</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800|Roboto:400,500,700" rel="stylesheet">
    <!-- Theme CSS -->
    <link type="text/css" href="../assets/css/theme.css" rel="stylesheet">
    <!-- Demo CSS - No need to use these in your project -->
    <link type="text/css" href="../assets/css/demo.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-transparent navbar-dark bg-dark py-4">
      <!-- ... (your navigation) ... -->
    </nav>
    <main class="main">
      <section class="py-xl bg-cover bg-size--cover" style="background-image: url('../assets/images/backgrounds/img-1.jpg')">
        <!-- ... (your background image section) ... -->
        <div class="container d-flex align-items-center no-padding">
          <div class="col">
            <div class="row justify-content-center">
              <div class="col-lg-4">
                <div class="card bg-primary text-white">
                  <div class="card-body">
                    <button type="button" class="btn btn-primary btn-nobg btn-zoom--hover mb-5">
                      <span class="btn-inner--icon"><i class="fas fa-arrow-left"></i></span>
                    </button>
                    <span class="clearfix"></span>
                    <img src="../assets/images/brand/Patient.png" style="width: 100px;">
                    <h4 class="heading h3 text-white pt-3 pb-5">Create New Account</h4>
                    <!-- Modify the form action to match the PHP script -->
                    <form action="" method="post" class="form-primary">
                      <div class="form-group">
                        <input type="text" class="form-control" name="first_name" placeholder="First Name" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="phone_number" placeholder="Phone Number" required>
                      </div>
                      <div class="form-group">
                        <input type="email" class="form-control" name="email" placeholder="Email" required>
                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" name="password" placeholder="Password" required>
                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password" required>
                      </div>
                      <button type="submit" name="submit" class="btn btn-block btn-lg bg-white mt-4">Create an Account</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
 
    <!-- ... (your JavaScript includes) ... -->
  </body>
</html>

<?php
$checkDB = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit'])) {
        if (isset($_POST['first_name']) && isset($_POST['last_name']) &&
            isset($_POST['phone_number']) && isset($_POST['email']) && 
            isset($_POST['password']) && isset($_POST['confirmpassword'])) {

            $firstname = $_POST['first_name'];
            $lastname = $_POST['last_name'];
            $phone = $_POST['phone_number'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $confirmpassword = $_POST['confirmpassword'];

            // Include the database connection script
            include "connect.php";

            if ($mysqli->connect_error) {
                die("Can't connect to the database");
            }

            if ($password !== $confirmpassword) {
                echo 'Passwords do not match';
            } else {
                // Check if the email already exists in the database
                $checkEmail = "SELECT email FROM patients WHERE email = ?";
                $checkDB = $mysqli->prepare($checkEmail);
                $checkDB->bind_param("s", $email);
                $checkDB->execute();
                $checkDB->store_result();
                $numRows = $checkDB->num_rows;
                
                if ($numRows > 0) {
                    // Email already exists in the database
                    echo "Email already registered. Please choose a different email.";
                } else {
                    // Email is unique, registration continues

                    // Now, prepare and execute the INSERT query
                    $sql = "INSERT INTO patients (first_name, last_name, phone_number, email, password_hash) VALUES (?, ?, ?, ?, ?)";
                    $password_h = password_hash($confirmpassword, PASSWORD_DEFAULT);

                    $checkDB->close();

                    $checkDB = $mysqli->prepare($sql);
                    $checkDB->bind_param("sssss", $firstname, $lastname, $phone, $email, $password_h);

                    if ($checkDB->execute()) {
                        // Registration was successful
                        header("Location: sign-in.html"); // Redirect to a success page
                        exit();
                    } else {
                        echo "Error: " . $checkDB->error;
                    }

                    $checkDB->close();
                }
            }
            $mysqli->close();
        } else {
            echo "All fields are required.";
        }
    } else {
        echo "Submit button is not set";
    }
}
?>