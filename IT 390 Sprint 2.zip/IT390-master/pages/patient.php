<?php
$checkDB = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit'])) {
        if (isset($_POST['first_name']) && isset($_POST['last_name']) &&
            isset($_POST['phone_number']) && isset($_POST['MRN']) && 
            isset($_POST['insurance']) && isset($_POST['reason'])) {

            $firstname = $_POST['first_name'];
            $lastname = $_POST['last_name'];
            $phone = $_POST['phone_number'];
            $mrn = $_POST['MRN'];
            $insurance = $_POST['insurance'];
            $reason = $_POST['reason'];

            // Include the database connection script
            include "connect.php";

            if ($mysqli->connect_error) {
                die("Can't connect to the database");
            }

            $sql = "INSERT INTO profile (first_name, last_name, phone_number, MRN, insurance, reason) VALUES (?, ?, ?, ?, ?, ?)";
            
            $checkDB = $mysqli->prepare($sql);

            if ($checkDB) {
                $checkDB->bind_param("ssssss", $firstname, $lastname, $phone, $mrn, $insurance, $reason);
                
                if ($checkDB->execute()) {
                    // Registration was successful
                    header("Location: sign-in.html"); // Redirect to a success page
                    exit();
                } else {
                    echo "Error: " . $checkDB->error;
                }

                $checkDB->close();
            } else {
                echo "Error preparing the SQL statement";
            }
            
            $mysqli->close();
        } else {
            echo "All fields are required.";
        }
    } else {
        echo "Submit button is not set";
    }
}
?>
