<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Probably the most complete UI kit out there. Multiple functionalities and controls added,  extended color palette and beautiful typography, designed as its own extended version of Bootstrap at  the highest level of quality.                             ">
    <meta name="author" content="Webpixels">
    <title>Patient Pathway Portal - IT 390</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800|Roboto:400,500,700" rel="stylesheet">
    <!-- Theme CSS -->
    <link type="text/css" href="../assets/css/theme.css" rel="stylesheet">
    <!-- Demo CSS - No need to use these in your project -->
    <link type="text/css" href="../assets/css/demo.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-transparent navbar-dark bg-dark py-4">
      <!-- ... (your navigation) ... -->
    </nav>
    <main class="main">
      <section class="py-xl bg-cover bg-size--cover" style="background-image: url('../assets/images/backgrounds/img-1.jpg')">
        <!-- ... (your background image section) ... -->
        <div class="container d-flex align-items-center no-padding">
          <div class="col">
            <div class="row justify-content-center">
              <div class="col-lg-4">
                <div class="card bg-primary text-white">
                  <div class="card-body">
                    <button type="button" class="btn btn-primary btn-nobg btn-zoom--hover mb-5">
                      <span class="btn-inner--icon"><i class="fas fa-arrow-left"></i></span>
                    </button>
                    <span class="clearfix"></span>
                    <img src="../assets/images/brand/Patient.png" style="width: 100px;">
                    <h4 class="heading h3 text-white pt-3 pb-5">Create New Account</h4>
                    <!-- Modify the form action to match the PHP script -->
                    <form action="new_user.php" method="post" class="form-primary">
                      <div class="form-group">
                        <input type="text" class="form-control" name="first_name" placeholder="First Name" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="phone_number" placeholder="Phone Number" required>
                      </div>
                      <div class="form-group">
                        <input type="email" class="form-control" name="email" placeholder="Email" required>
                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" name="password" placeholder="Password" required>
                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password" required>
                      </div>
                      <button type="submit" name="submit" class="btn btn-block btn-lg bg-white mt-4">Create an Account</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
 
    <!-- ... (your JavaScript includes) ... -->
  </body>
</html>
