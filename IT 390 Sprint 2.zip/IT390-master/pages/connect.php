<?php
$user = 'root';
$pass = '';
$dbName = 'patient pathway';

$mysqli = new mysqli('localhost', $user, $pass, $dbName);

?>
